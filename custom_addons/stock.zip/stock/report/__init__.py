# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import stock_forecasted
from . import report_stock_quantity
from . import report_stock_reception
from . import report_stock_rule
from . import stock_traceability
from . import product_label_report
